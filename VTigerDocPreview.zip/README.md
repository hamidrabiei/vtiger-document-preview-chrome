# vtiger-document-preview-chrome
Document preview Chrome plugin for VTiger

Currently supports Image preview on Tickets page for VTiger 6. 
Also removes Content-Disposition header from VTiger attachments, which allows the files to be opened in Browser without downloading.

Screenshot
![VTiger Document preview Screenshot](https://raw.githubusercontent.com/kunalgrover05/vtiger-document-preview-chrome/master/screenshot.png)
